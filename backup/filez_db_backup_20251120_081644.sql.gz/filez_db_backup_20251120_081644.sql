--
-- PostgreSQL database dump
--

\restrict x32mS2ZkVzKX1e05ChD4MR4N3YjBL4zIMrXhtOcaHPso0nifVoAVK1uXcrxUCqq

-- Dumped from database version 17.6 (Ubuntu 17.6-0ubuntu0.25.04.1)
-- Dumped by pg_dump version 17.6 (Ubuntu 17.6-0ubuntu0.25.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.uploads DROP CONSTRAINT uploads_folder_id_fkey;
ALTER TABLE ONLY public.folders DROP CONSTRAINT folders_parent_id_fkey;
ALTER TABLE ONLY public.bookmarks DROP CONSTRAINT bookmarks_upload_id_fkey;
DROP INDEX public.idx_uploads_share_token;
DROP INDEX public.idx_uploads_folder_id;
DROP INDEX public.idx_uploads_created_at;
DROP INDEX public.idx_saved_searches_user;
DROP INDEX public.idx_folders_parent_id;
DROP INDEX public.idx_bookmarks_user;
DROP INDEX public.idx_bookmarks_upload;
ALTER TABLE ONLY public.uploads DROP CONSTRAINT uploads_share_token_key;
ALTER TABLE ONLY public.uploads DROP CONSTRAINT uploads_pkey;
ALTER TABLE ONLY public.saved_searches DROP CONSTRAINT saved_searches_pkey;
ALTER TABLE ONLY public.folders DROP CONSTRAINT folders_pkey;
ALTER TABLE ONLY public.bookmarks DROP CONSTRAINT bookmarks_user_id_upload_id_key;
ALTER TABLE ONLY public.bookmarks DROP CONSTRAINT bookmarks_pkey;
DROP TABLE public.uploads;
DROP TABLE public.saved_searches;
DROP TABLE public.folders;
DROP TABLE public.bookmarks;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bookmarks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bookmarks (
    id character varying(255) NOT NULL,
    user_id character varying(255) DEFAULT 'default_user'::character varying NOT NULL,
    upload_id character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: folders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.folders (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    parent_id character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    color character varying(50) DEFAULT 'blue'::character varying
);


--
-- Name: saved_searches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.saved_searches (
    id character varying(255) NOT NULL,
    user_id character varying(255) DEFAULT 'default_user'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    query text NOT NULL,
    filters jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: uploads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.uploads (
    id character varying(255) NOT NULL,
    name character varying(500) NOT NULL,
    url text NOT NULL,
    file_type character varying(100) NOT NULL,
    file_size integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    folder_id character varying(255),
    tags text[],
    is_public boolean DEFAULT false,
    share_token character varying(255),
    is_encrypted boolean DEFAULT false,
    encryption_metadata text,
    document_type character varying(100),
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Data for Name: bookmarks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bookmarks (id, user_id, upload_id, created_at) FROM stdin;
\.


--
-- Data for Name: folders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.folders (id, name, parent_id, created_at, updated_at, color) FROM stdin;
\.


--
-- Data for Name: saved_searches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.saved_searches (id, user_id, name, query, filters, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: uploads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.uploads (id, name, url, file_type, file_size, created_at, folder_id, tags, is_public, share_token, is_encrypted, encryption_metadata, document_type, updated_at) FROM stdin;
\.


--
-- Name: bookmarks bookmarks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookmarks
    ADD CONSTRAINT bookmarks_pkey PRIMARY KEY (id);


--
-- Name: bookmarks bookmarks_user_id_upload_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookmarks
    ADD CONSTRAINT bookmarks_user_id_upload_id_key UNIQUE (user_id, upload_id);


--
-- Name: folders folders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT folders_pkey PRIMARY KEY (id);


--
-- Name: saved_searches saved_searches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_searches
    ADD CONSTRAINT saved_searches_pkey PRIMARY KEY (id);


--
-- Name: uploads uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uploads
    ADD CONSTRAINT uploads_pkey PRIMARY KEY (id);


--
-- Name: uploads uploads_share_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uploads
    ADD CONSTRAINT uploads_share_token_key UNIQUE (share_token);


--
-- Name: idx_bookmarks_upload; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bookmarks_upload ON public.bookmarks USING btree (upload_id);


--
-- Name: idx_bookmarks_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bookmarks_user ON public.bookmarks USING btree (user_id);


--
-- Name: idx_folders_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_folders_parent_id ON public.folders USING btree (parent_id);


--
-- Name: idx_saved_searches_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_saved_searches_user ON public.saved_searches USING btree (user_id);


--
-- Name: idx_uploads_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uploads_created_at ON public.uploads USING btree (created_at DESC);


--
-- Name: idx_uploads_folder_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uploads_folder_id ON public.uploads USING btree (folder_id);


--
-- Name: idx_uploads_share_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uploads_share_token ON public.uploads USING btree (share_token);


--
-- Name: bookmarks bookmarks_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookmarks
    ADD CONSTRAINT bookmarks_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES public.uploads(id) ON DELETE CASCADE;


--
-- Name: folders folders_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT folders_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.folders(id) ON DELETE CASCADE;


--
-- Name: uploads uploads_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uploads
    ADD CONSTRAINT uploads_folder_id_fkey FOREIGN KEY (folder_id) REFERENCES public.folders(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict x32mS2ZkVzKX1e05ChD4MR4N3YjBL4zIMrXhtOcaHPso0nifVoAVK1uXcrxUCqq

