-- Run this SQL to create the database
-- You can run it with: psql -U postgres -f db/create-database.sql

CREATE DATABASE fileupload;
