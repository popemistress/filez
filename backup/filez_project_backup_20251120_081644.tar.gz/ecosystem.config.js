module.exports = {
  apps: [{
    name: 'filez',
    script: 'node_modules/.bin/next',
    args: 'start',
    cwd: '/home/yamz/sites/filez',
    exec_mode: 'fork',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '800M',
    node_args: '--max-old-space-size=600',
    env: {
      NODE_ENV: 'production',
      PORT: 3003,
      HOST: '178.128.128.110',
      NODE_OPTIONS: '--max-old-space-size=600'
    }
  }]
};
